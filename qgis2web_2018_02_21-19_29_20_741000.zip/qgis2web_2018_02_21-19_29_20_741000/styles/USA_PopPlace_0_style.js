var size = 0;
var placement = 'point';

var style_USA_PopPlace_0 = ;
