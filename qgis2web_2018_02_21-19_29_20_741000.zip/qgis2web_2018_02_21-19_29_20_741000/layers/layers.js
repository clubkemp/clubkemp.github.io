var wms_layers = [];
var format_USA_PopPlace_0 = new ol.format.GeoJSON();
var features_USA_PopPlace_0 = format_USA_PopPlace_0.readFeatures(json_USA_PopPlace_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_USA_PopPlace_0 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_USA_PopPlace_0.addFeatures(features_USA_PopPlace_0);var lyr_USA_PopPlace_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_USA_PopPlace_0, 
                style: style_USA_PopPlace_0,
                title: '<img src="styles/legend/USA_PopPlace_0.png" /> USA_PopPlace'
            });

lyr_USA_PopPlace_0.setVisible(true);
var layersList = [lyr_USA_PopPlace_0];
lyr_USA_PopPlace_0.set('fieldAliases', {'scalerank': 'scalerank', 'natscale': 'natscale', 'labelrank': 'labelrank', 'featurecla': 'featurecla', 'name': 'name', 'namepar': 'namepar', 'namealt': 'namealt', 'diffascii': 'diffascii', 'nameascii': 'nameascii', 'adm0cap': 'adm0cap', 'capalt': 'capalt', 'capin': 'capin', 'worldcity': 'worldcity', 'megacity': 'megacity', 'sov0name': 'sov0name', 'sov_a3': 'sov_a3', 'adm0name': 'adm0name', 'adm0_a3': 'adm0_a3', 'adm1name': 'adm1name', 'iso_a2': 'iso_a2', 'note': 'note', 'latitude': 'latitude', 'longitude': 'longitude', 'changed': 'changed', 'namediff': 'namediff', 'diffnote': 'diffnote', 'pop_max': 'pop_max', 'pop_min': 'pop_min', 'pop_other': 'pop_other', 'rank_max': 'rank_max', 'rank_min': 'rank_min', 'geonameid': 'geonameid', 'meganame': 'meganame', 'ls_name': 'ls_name', 'ls_match': 'ls_match', 'checkme': 'checkme', 'min_zoom': 'min_zoom', });
lyr_USA_PopPlace_0.set('fieldImages', {'scalerank': 'TextEdit', 'natscale': 'TextEdit', 'labelrank': 'TextEdit', 'featurecla': 'TextEdit', 'name': 'TextEdit', 'namepar': 'TextEdit', 'namealt': 'TextEdit', 'diffascii': 'TextEdit', 'nameascii': 'TextEdit', 'adm0cap': 'TextEdit', 'capalt': 'TextEdit', 'capin': 'TextEdit', 'worldcity': 'TextEdit', 'megacity': 'TextEdit', 'sov0name': 'TextEdit', 'sov_a3': 'TextEdit', 'adm0name': 'TextEdit', 'adm0_a3': 'TextEdit', 'adm1name': 'TextEdit', 'iso_a2': 'TextEdit', 'note': 'TextEdit', 'latitude': 'TextEdit', 'longitude': 'TextEdit', 'changed': 'TextEdit', 'namediff': 'TextEdit', 'diffnote': 'TextEdit', 'pop_max': 'TextEdit', 'pop_min': 'TextEdit', 'pop_other': 'TextEdit', 'rank_max': 'TextEdit', 'rank_min': 'TextEdit', 'geonameid': 'TextEdit', 'meganame': 'TextEdit', 'ls_name': 'TextEdit', 'ls_match': 'TextEdit', 'checkme': 'TextEdit', 'min_zoom': 'TextEdit', });
lyr_USA_PopPlace_0.set('fieldLabels', {'scalerank': 'no label', 'natscale': 'no label', 'labelrank': 'no label', 'featurecla': 'no label', 'name': 'no label', 'namepar': 'no label', 'namealt': 'no label', 'diffascii': 'no label', 'nameascii': 'no label', 'adm0cap': 'no label', 'capalt': 'no label', 'capin': 'no label', 'worldcity': 'no label', 'megacity': 'no label', 'sov0name': 'no label', 'sov_a3': 'no label', 'adm0name': 'no label', 'adm0_a3': 'no label', 'adm1name': 'no label', 'iso_a2': 'no label', 'note': 'no label', 'latitude': 'no label', 'longitude': 'no label', 'changed': 'no label', 'namediff': 'no label', 'diffnote': 'no label', 'pop_max': 'no label', 'pop_min': 'no label', 'pop_other': 'no label', 'rank_max': 'no label', 'rank_min': 'no label', 'geonameid': 'no label', 'meganame': 'no label', 'ls_name': 'no label', 'ls_match': 'no label', 'checkme': 'no label', 'min_zoom': 'no label', });
lyr_USA_PopPlace_0.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});